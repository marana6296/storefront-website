const products = [
  {id:"latte", name:"Brew Haven House Latte", price:5.50, category:"Coffee", image:"images/latte.svg", description:"Espresso with steamed milk and a light layer of foam.", stock:30},
  {id:"coldbrew", name:"Cold Brew Coffee", price:4.75, category:"Coffee", image:"images/cold-brew.svg", description:"Smooth, chilled coffee with a rich flavor.", stock:25},
  {id:"muffin", name:"Blueberry Muffin", price:3.25, category:"Bakery", image:"images/muffin.svg", description:"Freshly baked muffin made with blueberries.", stock:18},
  {id:"beans", name:"Brew Haven Coffee Beans", price:14.00, category:"Coffee Beans", image:"images/beans.svg", description:"A packaged bag of Brew Haven coffee beans for brewing at home.", stock:20},
  {id:"mug", name:"Brew Haven Travel Mug", price:18.00, category:"Merchandise", image:"images/travel-mug.svg", description:"A reusable travel mug featuring the Brew Haven brand.", stock:12},
  {id:"mocha", name:"Chocolate Mocha", price:5.75, category:"Coffee", image:"images/latte.svg", description:"Espresso, steamed milk, and chocolate flavor topped with foam.", stock:15},
  {id:"caramel", name:"Caramel Macchiato", price:6.00, category:"Coffee", image:"images/caramel.svg", description:"Espresso and creamy milk finished with caramel flavor.", stock:14},
  {id:"croissant", name:"Butter Croissant", price:3.50, category:"Bakery", image:"images/croissant.svg", description:"Flaky, buttery pastry baked fresh for the morning rush.", stock:16},
  {id:"icedtea", name:"Peach Iced Tea", price:4.25, category:"Cold Drinks", image:"images/iced-tea.svg", description:"Refreshing iced tea with a bright peach flavor.", stock:22},
  {id:"tumbler", name:"Brew Haven Tumbler", price:22.00, category:"Merchandise", image:"images/tumbler.svg", description:"Insulated reusable tumbler for coffee on the go.", stock:10}
];

const productMap = Object.fromEntries(products.map(p => [p.id, p]));
const coupons = { BREW10: 0.10, COFFEE15: 0.15 };

function getCart() {
  return JSON.parse(localStorage.getItem("brewHavenCart") || "[]");
}
function saveCart(cart) {
  localStorage.setItem("brewHavenCart", JSON.stringify(cart));
}
function getInventory() {
  const saved = JSON.parse(localStorage.getItem("brewHavenInventory") || "null");
  if (saved) return saved;
  const initial = Object.fromEntries(products.map(p => [p.id, p.stock]));
  localStorage.setItem("brewHavenInventory", JSON.stringify(initial));
  return initial;
}
function saveInventory(inventory) {
  localStorage.setItem("brewHavenInventory", JSON.stringify(inventory));
}
function getCoupon() { return localStorage.getItem("brewHavenCoupon") || ""; }
function saveCoupon(code) {
  if (code) localStorage.setItem("brewHavenCoupon", code);
  else localStorage.removeItem("brewHavenCoupon");
}
function showFeedback(message, type = "success") {
  let toast = document.getElementById("cart-feedback");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "cart-feedback";
    toast.className = "toast";
    toast.setAttribute("role", "status");
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.className = `toast ${type} show`;
  clearTimeout(window.feedbackTimer);
  window.feedbackTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}
function updateCartCount() {
  const count = getCart().reduce((sum, x) => sum + x.qty, 0);
  document.querySelectorAll(".cart-count").forEach(el => el.textContent = count);
}
function addToCart(id) {
  const inventory = getInventory();
  if ((inventory[id] || 0) <= 0) {
    showFeedback("Out of Stock", "error");
    return;
  }
  const cart = getCart();
  const item = cart.find(x => x.id === id);
  if (item) item.qty++;
  else cart.push({id, qty: 1});
  inventory[id]--;
  saveCart(cart);
  saveInventory(inventory);
  updateCartCount();
  renderProducts();
  showFeedback(`${productMap[id].name} added to your cart.`);
}
function removeOneFromCart(id) {
  const cart = getCart();
  const index = cart.findIndex(x => x.id === id);
  if (index === -1) return;
  cart[index].qty--;
  if (cart[index].qty <= 0) cart.splice(index, 1);
  const inventory = getInventory();
  inventory[id] = (inventory[id] || 0) + 1;
  saveCart(cart);
  saveInventory(inventory);
  updateCartCount();
  renderCart();
  renderProducts();
}
function addOneFromCart(id) {
  const inventory = getInventory();
  if ((inventory[id] || 0) <= 0) {
    showFeedback("Out of Stock", "error");
    return;
  }
  const cart = getCart();
  const item = cart.find(x => x.id === id);
  if (!item) return;
  item.qty++;
  inventory[id]--;
  saveCart(cart);
  saveInventory(inventory);
  updateCartCount();
  renderCart();
  renderProducts();
}
function removeItem(id) {
  const cart = getCart();
  const index = cart.findIndex(x => x.id === id);
  if (index === -1) return;
  const qtyReturned = cart[index].qty;
  cart.splice(index, 1);
  const inventory = getInventory();
  inventory[id] = (inventory[id] || 0) + qtyReturned;
  saveCart(cart);
  saveInventory(inventory);
  updateCartCount();
  renderCart();
  renderProducts();
  showFeedback(`${productMap[id].name} removed from your cart.`);
}
function clearCart() {
  const cart = getCart();
  if (!cart.length) return;
  const inventory = getInventory();
  cart.forEach(item => { inventory[item.id] = (inventory[item.id] || 0) + item.qty; });
  saveInventory(inventory);
  saveCart([]);
  saveCoupon("");
  updateCartCount();
  renderCart();
  renderProducts();
  showFeedback("Your cart has been cleared.");
}
function renderProducts() {
  const grid = document.getElementById("product-grid");
  if (!grid) return;
  const inventory = getInventory();
  grid.innerHTML = "";
  products.forEach(product => {
    const stock = inventory[product.id] ?? product.stock;
    const out = stock === 0;
    grid.insertAdjacentHTML("beforeend", `
      <article class="card product-card ${out ? "out-of-stock" : ""}">
        <img src="${product.image}" alt="${product.name}">
        <span class="category">${product.category}</span>
        <h2>${product.name}</h2>
        <p>${product.description}</p>
        <p class="stock ${out ? "stock-out" : ""}">${out ? "Out of Stock" : `Available: ${stock}`}</p>
        <p class="price">$${product.price.toFixed(2)}</p>
        <button class="btn" ${out ? 'disabled title="Out of Stock"' : ''} onclick="addToCart('${product.id}')">${out ? "Out of Stock" : "Add to Cart"}</button>
      </article>`);
  });
}
function renderCart() {
  const area = document.getElementById("cart-items");
  if (!area) return;
  const cart = getCart();
  const clearButton = document.getElementById("clear-cart");
  const checkoutButton = document.getElementById("checkout-button");
  if (clearButton) clearButton.disabled = cart.length === 0;
  if (checkoutButton) checkoutButton.classList.toggle("disabled-link", cart.length === 0);
  if (!cart.length) {
    area.innerHTML = `<tr><td colspan="5">Your cart is empty. <a href="shop.html">Shop the menu</a>.</td></tr>`;
    document.getElementById("cart-total").textContent = "$0.00";
    return;
  }
  let total = 0;
  area.innerHTML = cart.map(item => {
    const p = productMap[item.id];
    const line = p.price * item.qty;
    total += line;
    const available = getInventory()[item.id] || 0;
    return `<tr>
      <td>${p.name}</td><td>
        <div class="quantity-controls">
          <button type="button" aria-label="Decrease ${p.name} quantity" onclick="removeOneFromCart('${p.id}')">−</button>
          <span>${item.qty}</span>
          <button type="button" aria-label="Increase ${p.name} quantity" ${available === 0 ? 'disabled title="Out of Stock"' : ''} onclick="addOneFromCart('${p.id}')">+</button>
        </div>
      </td><td>$${p.price.toFixed(2)}</td><td>$${line.toFixed(2)}</td>
      <td><button class="btn small-btn" onclick="removeItem('${p.id}')">Remove</button></td>
    </tr>`;
  }).join("");
  document.getElementById("cart-total").textContent = "$" + total.toFixed(2);
}
function calculateSubtotal() { return getCart().reduce((sum,x) => sum + (productMap[x.id]?.price || 0) * x.qty, 0); }
function calculateDiscount(subtotal) { const code = getCoupon().toUpperCase(); return coupons[code] ? subtotal * coupons[code] : 0; }
function fillCheckout() {
  const el = document.getElementById("checkout-summary");
  if (!el) return;
  const cart = getCart();
  el.innerHTML = cart.length ? cart.map(x => { const p=productMap[x.id]; return `<li>${p.name} × ${x.qty} — $${(p.price*x.qty).toFixed(2)}</li>`; }).join("") : "<li>Your cart is empty.</li>";
  updateCheckoutTotals();
}
function updateCheckoutTotals() {
  const subtotal = calculateSubtotal(), discount = calculateDiscount(subtotal), total = subtotal - discount;
  const a=document.getElementById("checkout-subtotal"), b=document.getElementById("checkout-discount"), c=document.getElementById("checkout-total");
  if(a)a.textContent="$"+subtotal.toFixed(2); if(b)b.textContent="-$"+discount.toFixed(2); if(c)c.textContent="$"+total.toFixed(2);
}
function applyCoupon() {
  const input=document.getElementById("coupon"), message=document.getElementById("coupon-message");
  if(!input||!message)return;
  const code=input.value.trim().toUpperCase();
  if(coupons[code]) { saveCoupon(code); message.textContent=`Coupon ${code} applied: ${coupons[code]*100}% off your order.`; message.className="form-message success"; }
  else if(code) { saveCoupon(""); message.textContent="Coupon code not found. Try BREW10 or COFFEE15."; message.className="form-message error"; }
  else { saveCoupon(""); message.textContent="Enter a coupon code to apply a discount."; message.className="form-message error"; }
  updateCheckoutTotals();
}
function requiredValue(id) { return document.getElementById(id)?.value.trim() || ""; }
function validateCheckout() {
  if (!getCart().length) { document.getElementById("checkout-errors").textContent="Your cart is empty. Add an item before checking out."; return false; }
  const requiredIds=["ship-name","ship-address","ship-city","ship-state","ship-zip","ship-phone","card-name","card-number","expiration","security"];
  const missing=requiredIds.filter(id=>!requiredValue(id));
  const errors=[];
  if(missing.length) errors.push("Please complete all required fields.");
  const zip=requiredValue("ship-zip"); if(zip&&!/^\d{5}(-\d{4})?$/.test(zip)) errors.push("ZIP Code must be 5 digits or ZIP+4.");
  const phone=requiredValue("ship-phone"); if(phone&&!/^[-+()\d\s]{10,}$/.test(phone)) errors.push("Enter a valid phone number.");
  const card=requiredValue("card-number").replace(/\s|-/g,""); if(card&&!/^\d{13,19}$/.test(card)) errors.push("Credit Card Number must contain 13–19 digits.");
  const security=requiredValue("security"); if(security&&!/^\d{3,4}$/.test(security)) errors.push("Security Code must contain 3–4 digits.");
  const state=requiredValue("ship-state"); if(state&&!/^[A-Za-z]{2}$/.test(state)) errors.push("State must be a two-letter abbreviation.");
  const expiration=requiredValue("expiration"); if(expiration&&new Date(expiration+"-01")<new Date(new Date().getFullYear(),new Date().getMonth(),1)) errors.push("Expiration Date must be current or future.");
  document.getElementById("checkout-errors").textContent=errors.join(" ");
  return errors.length===0;
}
function completeOrder() {
  localStorage.setItem("brewHavenOrder", JSON.stringify({items:getCart(), total:calculateSubtotal()-calculateDiscount(calculateSubtotal()), placedAt:new Date().toISOString()}));
  saveCart([]);
  saveCoupon("");
  updateCartCount();
}
function setupForms() {
  const checkout=document.getElementById("checkout-form");
  if(checkout) checkout.addEventListener("submit",e=>{ if(!validateCheckout()) e.preventDefault(); else completeOrder(); });
  const contact=document.getElementById("contact-form");
  if(contact) contact.addEventListener("submit",e=>{
    e.preventDefault(); const email=requiredValue("contact-email"), message=requiredValue("contact-message"), errors=[];
    if(!email)errors.push("Email Address is required."); else if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))errors.push("Enter a valid email address.");
    if(!message)errors.push("Message is required.");
    document.getElementById("contact-errors").textContent=errors.join(" ");
    document.getElementById("contact-success").textContent=errors.length?"":"Thank you! Your message has been prepared successfully for this student-project demo.";
    if(!errors.length)contact.reset();
  });
}
document.addEventListener("DOMContentLoaded",()=>{ getInventory(); updateCartCount(); renderProducts(); renderCart(); fillCheckout(); setupForms(); });
