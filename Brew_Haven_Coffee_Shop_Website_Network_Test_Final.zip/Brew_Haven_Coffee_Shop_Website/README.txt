BREW HAVEN COFFEE SHOP - E-COMMERCE WEBSITE

Current Features
----------------
- Responsive Brew Haven coffee shop homepage.
- Dynamic Shop/Menu page with 10 products generated with JavaScript.
- Product images, descriptions, prices, categories, and inventory counts.
- Shopping cart with add, remove, quantity adjustment, and clear-cart controls.
- Cart totals and checkout navigation.
- Cart persistence through browser refresh using localStorage.
- Immediate add-to-cart feedback.
- Inventory awareness: stock decreases when products are added and returns when products are removed.
- Out-of-stock protection with an "Out of Stock" button/tooltip when stock reaches zero.
- Checkout purchase and shipping forms with JavaScript validation.
- Coupon validation and percentage discounts.
- Order processing and order confirmation.
- Contact form with required email and message fields.
- Network Connection Test page that displays local host name, communication port, transmission protocol, and last launch time.
- Responsive styling using the Brew Haven brand colors.

Pages
------
index.html             Store homepage
shop.html              Shop/Menu and dynamic product display
cart.html              Shopping cart
checkout.html          Checkout and shipping forms
confirmation.html      Order confirmation
contact.html           Contact form
network-test.html      Network Connection Test

Supporting Files
----------------
styles.css             External stylesheet
script.js              Shopping cart, inventory, checkout, coupon, and product logic
images/                Product images

Network Test
------------
Open network-test.html through VS Code Live Server. The page reads the browser's current
location information. A typical Live Server launch displays localhost or 127.0.0.1,
port 5500, HTTP, and the previous launch time (or a first-launch message).

Testing
-------
Open the extracted folder in Visual Studio Code, install "Live Server" by Ritwick Dey,
open network-test.html, and select "Go Live". Test the Shop/Menu, Cart, Checkout,
Confirmation, Contact, and Network Test pages before submission.
