# Brew Haven Coffee Shop Website

Files included:
- index.html — Store Homepage
- shop.html — Shop/Menu with images and descriptions of all five products
- cart.html — Shopping Cart
- checkout.html — Checkout
- confirmation.html — Order Confirmation
- styles.css — External stylesheet using the proposal colors
- script.js — Basic cart interaction
- images/ — Product image files

Proposal pages used: Store Homepage, Shop/Menu, Shopping Cart, Checkout, Order Confirmation.

Brand colors from the proposal:
Dark Coffee Brown #3B2416
Espresso #5C4033
Cream #FFF8E7
Caramel #C68B59
White #FFFFFF

To test locally, double-click index.html and use the navigation links.
