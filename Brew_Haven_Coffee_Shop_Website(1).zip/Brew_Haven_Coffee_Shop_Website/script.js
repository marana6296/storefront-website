const products = {
  latte:{name:"Brew Haven House Latte",price:5.50},
  coldbrew:{name:"Cold Brew Coffee",price:4.75},
  muffin:{name:"Blueberry Muffin",price:3.25},
  beans:{name:"Bag of Brew Haven Coffee Beans",price:14.00},
  mug:{name:"Brew Haven Travel Mug",price:18.00}
};
function getCart(){return JSON.parse(localStorage.getItem("brewHavenCart")||"[]")}
function saveCart(cart){localStorage.setItem("brewHavenCart",JSON.stringify(cart))}
function addToCart(id){
  const cart=getCart(); const item=cart.find(x=>x.id===id);
  if(item)item.qty++; else cart.push({id,qty:1});
  saveCart(cart); updateCartCount(); alert(products[id].name+" was added to your cart.");
}
function updateCartCount(){
  const count=getCart().reduce((sum,x)=>sum+x.qty,0);
  document.querySelectorAll(".cart-count").forEach(el=>el.textContent=count);
}
function renderCart(){
  const area=document.getElementById("cart-items"); if(!area)return;
  const cart=getCart();
  if(!cart.length){area.innerHTML="<p>Your cart is empty. <a href='shop.html'>Shop the menu</a>.</p>"; document.getElementById("cart-total").textContent="$0.00"; return;}
  let total=0;
  area.innerHTML=cart.map((item,i)=>{const p=products[item.id], line=p.price*item.qty; total+=line;
    return `<tr><td>${p.name}</td><td>${item.qty}</td><td>$${p.price.toFixed(2)}</td><td>$${line.toFixed(2)}</td><td><button class="btn" onclick="removeItem(${i})">Remove</button></td></tr>`}).join("");
  document.getElementById("cart-total").textContent="$"+total.toFixed(2);
}
function removeItem(i){const cart=getCart();cart.splice(i,1);saveCart(cart);renderCart();updateCartCount();}
function fillCheckout(){
  const el=document.getElementById("checkout-summary"); if(!el)return;
  const cart=getCart(); let total=0;
  el.innerHTML=cart.map(x=>{const p=products[x.id];total+=p.price*x.qty;return `<li>${p.name} × ${x.qty} — $${(p.price*x.qty).toFixed(2)}</li>`}).join("");
  document.getElementById("checkout-total").textContent="$"+total.toFixed(2);
}
document.addEventListener("DOMContentLoaded",()=>{updateCartCount();renderCart();fillCheckout();});
